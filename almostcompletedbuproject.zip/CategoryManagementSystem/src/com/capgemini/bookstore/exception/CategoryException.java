package com.capgemini.bookstore.exception;


@SuppressWarnings("serial")
public class CategoryException extends Exception{
	

	public CategoryException(String message) 
	{
		
		super(message);
	}

}
