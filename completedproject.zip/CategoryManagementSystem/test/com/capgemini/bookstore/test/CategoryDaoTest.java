package com.capgemini.bookstore.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.dao.CategoryDao;
import com.capgemini.bookstore.exception.CategoryException;

public class CategoryDaoTest {

	CategoryDao dao = null;

	@Before           //Annotation
	public void setUp() throws Exception {
		dao = new CategoryDao();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}
	/********************************************
	 * Test case for addCategoryDetails()
	 ************************************************/
	@Test
	public void testAddProduct() {

		CategoryBean product = new CategoryBean("Architecture");

		try {
			int genId = dao.addCategoryDetails(product);
			assertNotNull(genId);
		} catch (CategoryException e) {

		}
	}
	/********************************************
	 * Test case for retriveAll()
	 ************************************************/
    @Test 
	public void testRetriveAll() throws CategoryException {

		List<CategoryBean> retrive = dao.retriveAll();
		assertTrue(retrive.size() > 0);
	}
	/********************************************
	 * Test case for editCategoryDetails()
	 ************************************************/
	@Test
	public void editCategory() throws CategoryException{
		int editedRows=dao.editCategoryDetails("Language", "Action");
		assertTrue(editedRows==1);
	}
	/********************************************
	 * Test case for deleteCategoryDetails()
	 ************************************************/
	@Test
	public void deleteCategory() throws CategoryException{
		int deletedRows=dao.deleteCategoryDetails("Adventure");
		assertTrue(deletedRows==1);
	}
}
