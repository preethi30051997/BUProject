package com.capgemini.bookstore.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.service.CategoryService;

public class BookMain {

	static Scanner scanner = new Scanner(System.in);
	static CategoryService categoryService = new CategoryService();
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws CategoryException {

		PropertyConfigurator.configure("resources//log4j.properties");
		boolean validate = false;
		CategoryBean categoryBean = new CategoryBean(null);

		String productName = "";
		boolean productNameFlag = false;
		String categoryName = "";
		String existingCategory = "";
		String newCategory = "";

		do {
			validate = categoryService.validate();

			if (validate == true) {
				System.out.println("   ");
				System.out.println(" --WELCOME-- ");
				System.out.println("   ");
				System.out.println(" Category Management");

				System.out.println("\n*************************************");
			} else {
				System.out.println("Please Enter correct Email Id and Password !!!");
			}
		} while (validate == false);

		String count = "";
		do {
			System.out.println(
					"\n 1.Category Listing Page \n 2.New Category Page \n 3.Edit Category Page \n 4.Delete Category Confirmation Dialog ");
			boolean choiceFlag = false;
			do {
				System.out.println("\n Select an option:");
				try {

					int choice = scanner.nextInt();
					choiceFlag = true;

					switch (choice) {
					
					case 1:
						/**** Retrieve all the Category list ****/

						System.out.println("**** Category Listing Page ****");
						try {
							List<CategoryBean> list = categoryService.retriveAll();

							System.out.println(String.format("%-10s  %-10s %s", "Index", "ID", "Category Name"));

							for (CategoryBean bean : list) {
								System.out.println(String.format("%-10s %-10s %s", bean.getCategoryIndex(),
										bean.getCategoryId(), bean.getCategoryName()));
							}
						} catch (CategoryException categoryException) {
							System.err.println(categoryException.getMessage());
						}
						break;

					case 2:

						/**** Add category ****/
						
						scanner.nextLine();

						do {

							System.out.println("Enter the category name :");

							try {
								productName = scanner.nextLine();

								productNameFlag = categoryService.validateName(productName);
								// productNameFlag = true;
								break;

							} catch (CategoryException categoryException) {
								productNameFlag = false;
								logger.error("Category Name should contain only chars, first letter should be capital and must be 3 to 30");
								System.err.println(
										"Category Name should contain only chars, first letter should be capital and must be 3 to 30");

							}

						} while (!productNameFlag);

						categoryBean.setCategoryName(productName);
						try {
							int result = categoryService.addCategoryDetails(categoryBean);
							if (result != 0) {
								System.out.println("Category informations are stored successfully");
							}
						} catch (CategoryException categoryException) {
							System.err.println(categoryException.getMessage());
						}

						break;

					case 3:
						
						/**** Edit category ****/
						
						scanner.nextLine();
						int validName = 0;
						System.out.println("*****Edit Category Page*****");
						

						do {
							System.out.println("Enter the category name which is to be edited :");
							try {
							existingCategory = scanner.next();
							scanner.nextLine();
						
							categoryService.validateName(existingCategory);
							validName = categoryService.isValidName(existingCategory);
							System.out.println(validName);
							if (validName == 0)

								System.err.println("This category is doesn't exist in database");
							logger.error("This category is doesn't exist in database");
							
						}catch(CategoryException categoryException)
						{
							System.err.println(categoryException.getMessage());
						}
						} while (validName == 0);
						

						do {
							System.out.println("Enter the category name  to replace the exiting category :");
							try {
								newCategory = scanner.nextLine();

								productNameFlag = categoryService.validateName(newCategory);
								
								int editedRows = categoryService.editCategoryDetails(existingCategory, newCategory);
								if (editedRows == 1)
									System.out.println("Successfully edited....");
							} catch (CategoryException categoryException) {
								productNameFlag = false;
								logger.error("Category Name should contain only chars, first letter should be capital and must be 3 to 30");
								System.err.println(categoryException.getMessage());
							}
						} while (!productNameFlag);

						break;

					case 4:
						
						/**** Delete category ****/
						
						String option = "";
						int count1 = 0;
						int identification;
						System.out.println("*****Delete Category Confirmation Dialog*****");

						do {
							System.out.println("Enter the category name to delete:");
							categoryName = scanner.next();
							try {
								categoryService.validateName(categoryName);
								count1 = categoryService.isValidName(categoryName);
								System.out.println("Are you sure you want to delete the Category " + categoryName + "");
								do {
									System.out.println("Enter your choice Yes/No");
									option = scanner.next();
									if (option.equalsIgnoreCase("Yes")) {

										identification = categoryService.deleteCategoryDetails(categoryName);
										// System.out.println(identification);//printing the count message
										if (identification == 1) {

											System.out.println("Category is successfully deleted...");
										} else {
											throw new CategoryException("This category is doesn't exist in database");
										}
									}
									if (!option.equalsIgnoreCase("Yes") && !option.equalsIgnoreCase("No")) {
										System.err.println("Enter valid option");
									}

								} while (!option.equalsIgnoreCase("Yes") && !option.equalsIgnoreCase("No"));

							} catch (CategoryException categoryException) {
								logger.error("This category is doesn't exist in database ");
								System.err.println(categoryException.getMessage());
							}
						} while (count1 == 0);

						break;

					default:
						choiceFlag = false;
						System.out.println("Input should be 1 to 4");
						break;

					}
					// }
				} catch (InputMismatchException inputMismatchException) {
					scanner.nextLine();
					choiceFlag = false;
					logger.error("Enter digits only...");
					System.out.println("Enter digits only...");
				}
			} while (!choiceFlag);
			do {
				System.out.println("\n Do you want to continue Yes/No");
				count = scanner.next();
				if (!count.equalsIgnoreCase("Yes") && !count.equalsIgnoreCase("No")) {
					System.err.println("Enter the valid option to continue the process");
					logger.error("Enter the valid option to continue the process");
				}
			} while (!count.equalsIgnoreCase("Yes") && !count.equalsIgnoreCase("No"));

		} while (count.equalsIgnoreCase("Yes"));

		System.out.println("Successfully exited.....!!!");

	}

}
