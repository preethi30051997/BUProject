package com.capgemini.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.utility.DBConnection;

public class CategoryDao implements ICategoryDao {
	PreparedStatement preparedStatement;
	Connection connection;
	ResultSet resultSet;
	//static int categoryId = 1;
	static Scanner scanner = new Scanner(System.in);
	static Logger logger = Logger.getRootLogger();

	/****************************************************************
	 -Function Name     : addCategoryDetails(CategoryBean categoryBean)
	 -Input Parameters  : CategoryBean categoryBean
	 -Return Type       : int
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: Adding the Category Details
	 * **************************************************************/
	 

	public int addCategoryDetails(CategoryBean categoryBean) throws CategoryException {
		String getId = null;

		try {
			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_QUERY);
	
			preparedStatement.setString(1, categoryBean.getCategoryName());
			preparedStatement.executeQuery();
			preparedStatement = connection.prepareStatement(QueryMapper.CURRENT_VAL);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next())
				getId = resultSet.getString(1);

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new CategoryException("Already this category is existing in database");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CategoryException("Error in closing database connection");

			}
		}
	
		return Integer.parseInt(getId);
	}
	
	/****************************************************************
	 -Function Name     : retriveAll ()
	 -Input Parameters  : 
	 -Return Type       : List<CategoryBean>
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: Listing the Category Details
	 * **************************************************************/
	 
	public List<CategoryBean> retriveAll() throws CategoryException {

		List<CategoryBean> list = new ArrayList<>();

		connection = DBConnection.getConnection();
		
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				// int id=rs.getInt(1);
				// String id1=rs.getString(2);
				CategoryBean bean = new CategoryBean();
				bean.setCategoryId(resultSet.getString(1));
				bean.setCategoryName(resultSet.getString(2));
				bean.setCategoryIndex(resultSet.getString(3));
				list.add(bean);
			}
		} catch (SQLException sqlException) {
			throw new CategoryException("Unable to create Prepared Statement object");
		}
		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CategoryException("Error in closing database connection");

			}
		}

		return list;
	}
	
	/****************************************************************
	 -Function Name     : deleteCategoryDetails(String existingCategoryName)
	 -Input Parameters  : String existingCategoryName
	 -Return Type       : int
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: deleting the Category Details
	 * **************************************************************/
	public int deleteCategoryDetails(String existingCategoryName) throws CategoryException {
		
		int identification=0;
		try {

			connection = DBConnection.getConnection();
			
			preparedStatement = connection.prepareStatement(QueryMapper.DELETE_QUERY);
			preparedStatement.setString(1, existingCategoryName);
			identification = preparedStatement.executeUpdate();
			
		} 
		catch (SQLException sqlException) {
			
			logger.error(sqlException.getMessage());
			throw new CategoryException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CategoryException("Error in closing database connection");

			}
		}
		return identification;

	}
	/****************************************************************
	 -Function Name     : editCategoryDetails(String existingCategory, String newCategory)
	 -Input Parameters  : String existingCategory, String newCategory
	 -Return Type       : int
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: Editing the Category Details
	 * **************************************************************/
	public int editCategoryDetails(String existingCategory, String newCategory) throws CategoryException {

		try {

			connection = DBConnection.getConnection();
			preparedStatement = connection.prepareStatement(QueryMapper.EDIT_QUERY);
			preparedStatement.setString(1, newCategory);
			preparedStatement.setString(2, existingCategory);
			
			int editedRows=preparedStatement.executeUpdate();
			return editedRows;
		} catch (CategoryException categoryException) {
			logger.error( categoryException.getMessage());
			throw new CategoryException("Exception occured while editing the details");
		}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new CategoryException("Already existing in the database");
		}
		finally
		{
			try 
			{
				
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CategoryException("Error in closing database connection");

			}
		}
	}
	
	/****************************************************************
	 -Function Name     : isValidName(String existingCategory)
	 -Input Parameters  : String existingCategory
	 -Return Type       : int
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: Checks the validation
	 * **************************************************************/
	public int isValidName(String existingCategory) throws CategoryException {

		int verify = 0;

		try {
			connection = DBConnection.getConnection();
			
			preparedStatement = connection.prepareStatement(QueryMapper.VERIFY_QUERY);
			preparedStatement.setString(1, existingCategory);
			verify = preparedStatement.executeUpdate();
			return verify;
		} catch (SQLException sqlException) {

		//	e.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CategoryException("Technical problem occured");
		}	
		finally
		{
			try 
			{
				
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CategoryException("Error in closing database connection");

			}
		}

	}
}
