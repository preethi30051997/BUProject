package com.capgemini.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.utility.DBConnection;

public class LoginDao {
 Scanner scanner=new Scanner(System.in);
 
		 /****************************************************************
		 -Function Name     : validate() 
		 -Input Parameters  : 
		 -Return Type       : boolean
		 -Throws     		: CategoryException
		 -Author			: CAPGEMINI
		 -Date 				: 24/06/2019
		 -Description  		: validating the email and password
         ***************************************************************/
 
	public boolean validate() throws CategoryException {
	
	
		PreparedStatement preparedStatement;
	    Connection connection;
	    ResultSet resultSet;
	    try {
	    connection=DBConnection.getConnection();
		
	    preparedStatement=connection.prepareStatement(QueryMapper.LOGIN_QUERY);
		System.out.println("****Book_Store****");
		System.out.println("\nEnter Email :");
		String email=scanner.next();
		preparedStatement.setString(1, email);
		System.out.println("Enter password :");
		String password=scanner.next();
		preparedStatement.setString(2, password);
		resultSet=preparedStatement.executeQuery();
		while(resultSet.next())
		{
			return true;
		}
		return false;

	}
	catch (Exception e)
	{
		throw new CategoryException("Please Enter the correct Email and Password!!!");
	}
		
}}
