package com.capgemini.bookstore.dao;

public interface QueryMapper {
	public static final String RETRIVE_ALL_QUERY="SELECT * from Category_management order by category_name";
	public static final String INSERT_QUERY="insert into category_management values(index_seq.NEXTVAL,?,id_seq.NEXTVAL)";
	public static final String DELETE_QUERY="delete from category_management where category_name=?";
	public static final String EDIT_QUERY="update category_management set category_name=? where category_name=?";
	public static final String LOGIN_QUERY="SELECT * from admin where email=? and password=?";
    public static final String VERIFY_QUERY="SELECT category_name FROM Category_Management WHERE category_name=?";
    public static final String CURRENT_VAL="SELECT id_seq.CURRVAL FROM DUAL";
}
