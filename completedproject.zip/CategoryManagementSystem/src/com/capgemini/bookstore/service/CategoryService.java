package com.capgemini.bookstore.service;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.dao.CategoryDao;
import com.capgemini.bookstore.dao.LoginDao;
import com.capgemini.bookstore.exception.CategoryException;

public class CategoryService implements ICategoryService {

	PreparedStatement preparedStatement;
	CategoryDao categoryDao = new CategoryDao();
	 /****************************************************************
	 -Function Name     : addCategoryDetails 
	 -Input Parameters  : CategoryBean categoryBean
	 -Return Type       : int
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: adding categories to database calls dao method addCategoryDetails(CategoryBean categoryBean)
    ***************************************************************/
	public int addCategoryDetails(CategoryBean categoryBean) throws CategoryException {
		categoryDao = new CategoryDao();
		int getId = categoryDao.addCategoryDetails(categoryBean);
		return getId;
	}
	 /****************************************************************
	 -Function Name     : retriveAll() 
	 -Input Parameters  : CategoryBean categoryBean
	 -Return Type       : 
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: retrieving all category details from the database calls dao method List<CategoryBean> retriveAll()
    ***************************************************************/
	public List<CategoryBean> retriveAll() throws CategoryException {

		categoryDao = new CategoryDao();
		return categoryDao.retriveAll();

	}
	 /****************************************************************
	 -Function Name     : deleteCategoryDetails(String categoryName)
	 -Input Parameters  : String categoryName
	 -Return Type       : int
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: delete categories into database calls dao method deleteCategoryDetails(String categoryName)
   ***************************************************************/
	public int deleteCategoryDetails(String categoryName) throws CategoryException {
		int identification=0;
		categoryDao = new CategoryDao();
		try {
			identification=	categoryDao.deleteCategoryDetails(categoryName);
		} catch (CategoryException categoryException) {

			throw new CategoryException("Tehnical problem occured refer log");
		}
		return identification;

	} /**************************************************************************
	 -Function Name     : editCategoryDetails(String existingCategory, String newCategory)
	 -Input Parameters  : String existingCategory, String newCategory
	 -Return Type       : int
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: edit categories into database calls dao method editCategoryDetails(String existingCategory, String newCategory)
   ******************************************************************************/

	public int editCategoryDetails(String existingCategory, String newCategory) throws CategoryException {

		categoryDao = new CategoryDao();
		return categoryDao.editCategoryDetails(existingCategory, newCategory);

	}
	 /****************************************************************************
	 -Function Name     : validateName(String name)
	 -Input Parameters  : String name
	 -Return Type       : boolean
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: Validating the category name pattern
   *******************************************************************************/
	public boolean validateName(String name) throws CategoryException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{1,29}";
		//String nameRegEx="^[a-zA-Z0-9 ]+$";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new CategoryException("Category Name should contain only chars, first letter should be capital and must be 3 to 30");
		}
		else
		{
		return true;
		}
	}
	 /****************************************************************************
	 -Function Name     : validate() 
	 -Input Parameters  : 
	 -Return Type       : boolean
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: validating the email and password
    ******************************************************************************/
	public boolean validate() throws CategoryException {

		LoginDao loginDoa = new LoginDao();
		boolean valid = loginDoa.validate();
		return valid;
	}
	/******************************************************************************
	 -Function Name     : isValidName(String existingCategory)
	 -Input Parameters  : String existingCategory
	 -Return Type       : int
	 -Throws     		: CategoryException
	 -Author			: CAPGEMINI
	 -Date 				: 24/06/2019
	 -Description  		: Validating the existing category name into the database
	 * ****************************************************************************/
	public int isValidName(String existingCategory) throws CategoryException {

		categoryDao = new CategoryDao();
		return categoryDao.isValidName(existingCategory);
	}

}
