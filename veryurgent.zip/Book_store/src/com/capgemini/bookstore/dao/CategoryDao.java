package com.capgemini.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.utility.CommonCon;

public class CategoryDao implements ICategoryDao {
	PreparedStatement pst;
	Connection cn;
	ResultSet rs;
	static int id = 1;
	static Scanner sc = new Scanner(System.in);
	static Logger logger = Logger.getRootLogger();

	/*
	 * public List<CategoryBean> getCategoryDetails(int id) throws CategoryException
	 * {
	 * 
	 * 
	 * }
	 */

	public int addCategoryDetails(CategoryBean PBobj) throws CategoryException {
		String getId = null;

		try {
			cn = CommonCon.getInstance().getConnection();

			pst = cn.prepareStatement(QueryMapper.INSERT_QUERY);
			// pst.setString(1, PBobj.getIndex_seq());
			// pst.setString(1,PBobj.getId());
			pst.setString(1, PBobj.getCategory_name());
			pst.executeQuery();
			pst = cn.prepareStatement(QueryMapper.CURRENT_VAL);
			rs = pst.executeQuery();

			while (rs.next())
				getId = rs.getString(1);

		} catch (SQLException e) {

			throw new CategoryException("unable to create Preapres Statement object");
		}
		return Integer.parseInt(getId);
	}

	public List<CategoryBean> retriveAll() throws CategoryException {

		List<CategoryBean> list = new ArrayList<>();

		cn = CommonCon.getInstance().getConnection();
		// Statement stmt = cn.createStatement();
		try {
			pst = cn.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			rs = pst.executeQuery();

			while (rs.next()) {

				// int id=rs.getInt(1);
				// String id1=rs.getString(2);
				CategoryBean bean = new CategoryBean();
				bean.setCategoryId(rs.getString(1));
				bean.setCategory_name(rs.getString(2));
				list.add(bean);
			}
		} catch (SQLException e) {
			throw new CategoryException("unable to create Preapres Statement object");
		}

		return list;
	}

	public void deleteCategoryDetails(String id1) throws CategoryException {
		String ch = "";
		try {

			cn = CommonCon.getInstance().getConnection();
			// System.out.println(id1);
			pst = cn.prepareStatement(QueryMapper.DELETE_QUERY);
			pst.setString(1, id1);
			System.out.println("Are you sure you want to delete Category with " + id1 + "");
			do {
				System.out.println("Enter your choice Yes/No");
				ch = sc.next();
				if (ch.equals("Yes")) {
					int identification = pst.executeUpdate();

					if (identification == 1) {

						System.out.println("Category is successfully deleted...");

					}
				}
				if (!ch.equals("Yes") && !ch.equals("No")) {
					System.err.println("Enter valid option");
				}

			} while (!ch.equals("Yes") && !ch.equals("No"));

		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			throw new CategoryException("Tehnical problem occured refer log");
		}

	}

	public void editCategoryDetails(String id2, String cname) {

		try {

			cn = CommonCon.getInstance().getConnection();
			pst = cn.prepareStatement(QueryMapper.EDIT_QUERY);
			pst.setString(1, cname);
			pst.setString(2, id2);
			pst.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int isValidId(String id1) throws CategoryException {

		int verify = 0;

		try {
			cn = CommonCon.getInstance().getConnection();
			// System.out.println("hjhgjhg");
			pst = cn.prepareStatement(QueryMapper.VERIFY_QUERY);
			pst.setString(1, id1);
			verify = pst.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
			logger.error(e.getMessage());
			throw new CategoryException("Technical problem occured");
		}
		if (verify == 1)
			return 1;
		else
			logger.error("Enter id is doesn't exist in database");
		throw new CategoryException("Enter id is doesn't exist in database");

	}
}
