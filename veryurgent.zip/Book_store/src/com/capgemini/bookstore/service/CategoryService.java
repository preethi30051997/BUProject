package com.capgemini.bookstore.service;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.dao.CategoryDao;
import com.capgemini.bookstore.dao.LoginDao;
import com.capgemini.bookstore.exception.CategoryException;

public class CategoryService implements ICategoryService {

	PreparedStatement pst;
	static int id = 1;
	static Scanner sc = new Scanner(System.in);
	CategoryDao bookdao = new CategoryDao();

	public int addCategoryDetails(CategoryBean PBobj) throws CategoryException {
		bookdao = new CategoryDao();
		int getId = bookdao.addCategoryDetails(PBobj);
		return getId;
	}

	public List<CategoryBean> retriveAll() throws CategoryException {

		bookdao = new CategoryDao();
		return bookdao.retriveAll();

	}

	public void deleteCategoryDetails(String id1) {
		bookdao = new CategoryDao();
		try {
			bookdao.deleteCategoryDetails(id1);
		} catch (CategoryException e) {

			e.printStackTrace();
		}
		// return 0;

	}

	public void editCategoryDetails(String id2, String cname) {

		bookdao = new CategoryDao();
		bookdao.editCategoryDetails(id2, cname);

	}

	public void validateName(String name) throws CategoryException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{1,29}";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new CategoryException("First letter should be capital and length must be in between 2 to 30 \n");
		}
	}

	public boolean validate() throws ClassNotFoundException, SQLException {

		LoginDao BKobj = new LoginDao();
		boolean valid = BKobj.validate();
		return valid;
	}

	public int isValidId(String id1) throws CategoryException {

		bookdao = new CategoryDao();
		return bookdao.isValidId(id1);
	}

}
