package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.exception.CategoryException;

public interface ICategoryService {

	public int addCategoryDetails(CategoryBean PBobj) throws CategoryException;

	public List<CategoryBean> retriveAll() throws CategoryException;

	public void deleteCategoryDetails(String id1);

	public void editCategoryDetails(String id2, String cname);

	public int isValidId(String id1) throws CategoryException;

	//public List<CategoryBean> getCategoryDetails(int id) throws CategoryException;
}
