package com.insurance.claim;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class BackControl extends HttpServlet{

	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		HttpSession session5=request.getSession(false);
		 String str=(String)session5.getAttribute("role");
		System.out.println("backcontrol for : "+str);
		 if(str.equals("Admin") )
		 {
		 request.getRequestDispatcher("/admin.jsp").include(request, response);
	     }
		 else if(str.equals("Agent"))
		   {
			 request.getRequestDispatcher("/agent.jsp").include(request, response);
		    }
		 else if(str.equals("Insured"))
		    {
			 request.getRequestDispatcher("/user.jsp").include(request, response);
		    }
			}
}
