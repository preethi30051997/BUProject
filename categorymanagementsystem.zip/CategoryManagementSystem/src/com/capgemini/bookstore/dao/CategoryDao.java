package com.capgemini.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.utility.DBConnection;

public class CategoryDao implements ICategoryDao {
	PreparedStatement preparedStatement;
	Connection connection;
	ResultSet resultSet;
	//static int categoryId = 1;
	static Scanner scanner = new Scanner(System.in);
	static Logger logger = Logger.getRootLogger();

	/*
	 * public List<CategoryBean> getCategoryDetails(int id) throws CategoryException
	 * {
	 * 
	 * 
	 * }
	 */

	public int addCategoryDetails(CategoryBean PBobj) throws CategoryException {
		String getId = null;

		try {
			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_QUERY);
			// pst.setString(1, PBobj.getIndex_seq());
			// pst.setString(1,PBobj.getId());
			preparedStatement.setString(1, PBobj.getCategoryName());
			preparedStatement.executeQuery();
			preparedStatement = connection.prepareStatement(QueryMapper.CURRENT_VAL);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next())
				getId = resultSet.getString(1);

		} catch (SQLException e) {

			throw new CategoryException("unable to create Preapres Statement object");
		}
		return Integer.parseInt(getId);
	}

	public List<CategoryBean> retriveAll() throws CategoryException {

		List<CategoryBean> list = new ArrayList<>();

		connection = DBConnection.getConnection();
		
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				// int id=rs.getInt(1);
				// String id1=rs.getString(2);
				CategoryBean bean = new CategoryBean();
				bean.setCategoryId(resultSet.getString(1));
				bean.setCategoryName(resultSet.getString(2));
				list.add(bean);
			}
		} catch (SQLException e) {
			throw new CategoryException("unable to create Preapres Statement object");
		}

		return list;
	}

	public int deleteCategoryDetails(String id1) throws CategoryException {
		String ch = "";
		int identification=0;
		try {

			connection = DBConnection.getConnection();
			// System.out.println(id1);
			preparedStatement = connection.prepareStatement(QueryMapper.DELETE_QUERY);
			preparedStatement.setString(1, id1);
			System.out.println("Are you sure you want to delete Category with " + id1 + "");
			do {
				System.out.println("Enter your choice Yes/No");
				ch = scanner.next();
				if (ch.equalsIgnoreCase("Yes")) {
					identification = preparedStatement.executeUpdate();

					/*if (identification == 1) {

						

					}*/
				}
				if (!ch.equalsIgnoreCase("Yes") && !ch.equalsIgnoreCase("No")) {
					System.err.println("Enter valid option");
				}

			} while (!ch.equalsIgnoreCase("Yes") && !ch.equalsIgnoreCase("No"));

		} catch (SQLException e) {
			
			logger.error("Tehnical problem occured refer log");
			throw new CategoryException("Tehnical problem occured refer log");
		}
		return identification;

	}

	public int editCategoryDetails(String id2, String cname) throws CategoryException {

		try {

			connection = DBConnection.getConnection();
			preparedStatement = connection.prepareStatement(QueryMapper.EDIT_QUERY);
			preparedStatement.setString(1, cname);
			preparedStatement.setString(2, id2);
			
			int editedRows=preparedStatement.executeUpdate();
			return editedRows;
		} catch (Exception e) {
			throw new CategoryException("Exception occured while editing the details");
		}
	}

	public int isValidId(String id1) throws CategoryException {

		int verify = 0;

		try {
			connection = DBConnection.getConnection();
			
			preparedStatement = connection.prepareStatement(QueryMapper.VERIFY_QUERY);
			preparedStatement.setString(1, id1);
			verify = preparedStatement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
			logger.error("Technical problem occured");
			throw new CategoryException("Technical problem occured");
		}
		if (verify == 1)
			return 1;
		else
			logger.error("Enter id is doesn't exist in database");
		throw new CategoryException("Enter id is doesn't exist in database");

	}
}
