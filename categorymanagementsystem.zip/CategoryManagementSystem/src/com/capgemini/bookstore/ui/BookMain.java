package com.capgemini.bookstore.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.service.CategoryService;

public class BookMain {

	static Scanner scanner = new Scanner(System.in);
	static CategoryService categoryService = new CategoryService();
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws SQLException, CategoryException {

		PropertyConfigurator.configure("resources//log4j.properties");
		boolean validate = false;
		CategoryBean categoryBean = new CategoryBean(null);

		String productName = "";
		boolean productNameFlag = false;
		String categoryId1 = "";
		// String categoryId2 = "";
		do {
			validate = categoryService.validate();

			if (validate == true) {
				System.out.println("   ");
				System.out.println("WELCOME ");
				System.out.println("   ");
				System.out.println("Category Management");

				System.out.println("*************************************");
			} else {
				System.out.println("Please Enter the correct Email and Password!!!");
			}
		} while (validate == false);

		char ch1 = '\0';
		do {
			System.out.println(
					"\n 1.Category Listing Page \n 2.New Category Page \n 3.Edit Category Page \n 4.Delete Category Confirmation Dialog ");
			boolean choiceFlag = false;
			do {
				System.out.println("\n Select an option:");
				try {

					int ch = scanner.nextInt();
					choiceFlag = true;
					/*
					 * if (ch > 5) { System.out.println("Please enter a valid option!!!!"); } else {
					 */

					switch (ch) {
					case 1:
						System.out.println("*****Category Listing Page*****");

						List<CategoryBean> list = categoryService.retriveAll();

						System.out.println(String.format("%-10s %s", "ID", "Category Name"));

						for (CategoryBean bean : list) {
							System.out.println(String.format("%-10s %s", bean.getCategoryId(), bean.getCategoryName()));
						}

						break;

					case 2:
						scanner.nextLine();

						do {

							System.out.println("Enter the category name :");

							try {
								productName = scanner.nextLine();
								categoryService.validateName(productName);
								productNameFlag = true;
								break;

							} catch (CategoryException e) {
								productNameFlag = false;
								logger.error("First letter should be capital and length must be in between 2 to 30");
								System.err.println(
										"First letter should be capital and length must be in between 2 to 30");

							}

						} while (!productNameFlag);

						categoryBean.setCategoryName(productName);
						int result = categoryService.addCategoryDetails(categoryBean);
						if (result != 0) {
							System.out.println("Category informations are stored successfully");
						}
						break;

					case 3:
						scanner.nextLine();
						int i = 0;
						System.out.println("*****Edit Category Page*****");
						do {
							System.out.println("Enter the Id which is to be edited :");
							categoryId1 = scanner.next();
							scanner.nextLine();

							i = categoryService.isValidId(categoryId1);

						} while (i == 0);

						do {
							System.out.println("Enter the category name :");
							try {
								productName = scanner.nextLine();

								categoryService.validateName(productName);
								productNameFlag = true;
							} catch (CategoryException e) {
								productNameFlag = false;
								logger.error("First letter should be capital and length must be in between 2 to 30");
								System.err.println("First letter should be capital and length must be in between 2 to 30");
							}
						} while (!productNameFlag);

						int editedRows=categoryService.editCategoryDetails(categoryId1, productName);
						if(editedRows==1)
						System.out.println("Successfully edited....");

						break;

					case 4:
						int c = 0;
						int identification;
						System.out.println("*****Delete Category Confirmation Dialog*****");

						do {
							System.out.println("Enter the Id which is to be deleted:");
							categoryId1 = scanner.next();
							try {
								c = categoryService.isValidId(categoryId1);

							} catch (CategoryException e) {
								logger.error("Enter id is doesn't exist in database");
								System.err.println("Enter id is doesn't exist in database");
							}
						} while (c == 0);
						identification = categoryService.deleteCategoryDetails(categoryId1);
						if (identification > 1) {
							System.out.println("Category is successfully deleted...");
						}
						break;
					 /*case 5: 
						 System.out.println("Exited....!!!!"); System.exit(0); break;
					 */
					default:
						choiceFlag = false;
						System.out.println("input should be 1 to 4");
						break;

					}
					// }
				} catch (InputMismatchException e) {
					scanner.nextLine();
					choiceFlag = false;
					logger.error("Enter digits only...");
					System.out.println("Enter digits only...");
				}
			} while (!choiceFlag);
			do {
				System.out.println("Do you want to continue Y/N");
				ch1 = scanner.next().charAt(0);
				if (ch1 != 'Y' && ch1 != 'N') {
					System.err.println("Enter the valid option to continue the process");
					logger.error("Enter the valid option to continue the process");
				}
			} while (ch1 != 'Y' && ch1 != 'N');

		} while (ch1 == 'Y');

		System.out.println("Successfully exited.....!!!");

	}

}
