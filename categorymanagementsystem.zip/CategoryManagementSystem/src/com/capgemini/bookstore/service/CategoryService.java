package com.capgemini.bookstore.service;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.dao.CategoryDao;
import com.capgemini.bookstore.dao.LoginDao;
import com.capgemini.bookstore.exception.CategoryException;

public class CategoryService implements ICategoryService {

	PreparedStatement preparedStatement;
	//static int categoryId = 1;
	//static Scanner scanner = new Scanner(System.in);
	CategoryDao categoryDao = new CategoryDao();

	public int addCategoryDetails(CategoryBean categoryBean) throws CategoryException {
		categoryDao = new CategoryDao();
		int getId = categoryDao.addCategoryDetails(categoryBean);
		return getId;
	}

	public List<CategoryBean> retriveAll() throws CategoryException {

		categoryDao = new CategoryDao();
		return categoryDao.retriveAll();

	}

	public int deleteCategoryDetails(String categoryId1) throws CategoryException {
		int identification=0;
		categoryDao = new CategoryDao();
		try {
			identification=	categoryDao.deleteCategoryDetails(categoryId1);
		} catch (CategoryException e) {

			throw new CategoryException("Tehnical problem occured refer log");
		}
		return identification;

	}

	public int editCategoryDetails(String categoryId2, String categoryName) throws CategoryException {

		categoryDao = new CategoryDao();
		return categoryDao.editCategoryDetails(categoryId2, categoryName);

	}

	public void validateName(String name) throws CategoryException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{1,29}";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new CategoryException("First letter should be capital and length must be in between 2 to 30 \n");
		}
	}

	public boolean validate() throws CategoryException {

		LoginDao loginDoa = new LoginDao();
		boolean valid = loginDoa.validate();
		return valid;
	}

	public int isValidId(String categoryId1) throws CategoryException {

		categoryDao = new CategoryDao();
		return categoryDao.isValidId(categoryId1);
	}

}
