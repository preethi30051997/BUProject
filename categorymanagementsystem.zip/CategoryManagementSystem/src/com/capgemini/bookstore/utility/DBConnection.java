package com.capgemini.bookstore.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.bookstore.exception.CategoryException;

public class DBConnection {

	private static Connection conn = null;
	
	public static Connection getConnection() throws CategoryException {
		
		File file = new File("resources/jdbc.properties");
		FileInputStream inputStream = null;
		Properties properties = new Properties();
		
		try {
			inputStream = new FileInputStream(file);
			properties.load(inputStream);
			
			String driver = properties.getProperty("driver");
			String url = properties.getProperty("dburl");
			String username = properties.getProperty("username");
			String password = properties.getProperty("password");
			
			
			Class.forName(driver);
			
			conn = DriverManager.getConnection(url, username, password);
			System.out.println("done");
			
		} catch (FileNotFoundException e) {
			throw new CategoryException("unable to create file object");
		} catch (IOException e) {
			throw new CategoryException("unable to load the data");
		} catch (ClassNotFoundException e) {
			throw new CategoryException("problem occured while loading the driver");
		} catch (SQLException e) {
			throw new CategoryException("problem occured while establishing the connection");
		}
		
		return conn;
		
	}
	
	
	
	/*
	private static DBConnection instance = null;
	private static Properties props = null;
	private static OracleDataSource dataSource = null;

	private DBConnection() throws CategoryException {

		try {
			props = loadProperties();
			dataSource = prepareDataSource();
		} catch (IOException e) {

			throw new CategoryException(" Could not read the database details from properties file ");

		} catch (SQLException e) {
			throw new CategoryException(e.getMessage());
		}

	}

	public static DBConnection getInstance() throws CategoryException {
		synchronized (DBConnection.class) {
			if (instance == null) {
				instance = new DBConnection();
			}
		}
		return instance;
	}

	public Connection getConnection() throws CategoryException {
		try {

			conn = dataSource.getConnection();

		} catch (SQLException e) {

			throw new CategoryException(" Database connection problem");
		}
		return conn;
	}

	private Properties loadProperties() throws IOException {

		if (props == null) {
			Properties newProps = new Properties();
			String fileName = "resources/jdbc.properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);

			inputStream.close();

			return newProps;
		} else {
			return props;
		}
	}

	private OracleDataSource prepareDataSource() throws SQLException {

		if (dataSource == null) {
			if (props != null) {
				String connectionURL = props.getProperty("dburl");
				String username = props.getProperty("username");
				String password = props.getProperty("password");

				dataSource = new OracleDataSource();

				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}
*/
}








